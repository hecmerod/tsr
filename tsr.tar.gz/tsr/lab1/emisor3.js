//Emisor de eventos (emisor3.js) -------------------------------------------

const Evento=require("./generadorEventos");

const evento1 = 'e1';
const evento2 = 'e2';
var incremento=0;

const emisor1 = Evento(evento1,'emisor1:   ',0);
const emisor2 = Evento(evento2,'emisor2:   ','');

function visualizar(entidad,evento,dato){
   console.log(entidad,evento+'··> ',dato);
}

emisor1.on(visualizar);
emisor2.on(visualizar);

let t = getRndInteger(2, 5) * 1000;
setTimeout(emisiones, t), t;

function emisiones(t) {
    emisor1.on(visualizar);
    emisor2.on(visualizar);
    console.log("Tiempo de llamada " + incremento + ": " + t / 1000);
    incremento++;

    var t = getRndInteger(2, 5) * 1000;    
    setTimeout(emisiones, t), t;    
}

function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1) ) + min;
}

//. . . . . . . . . . . . . .
