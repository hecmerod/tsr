const zmq = require('zeromq')
let work=[]

let sc = zmq.socket('router')
let sw = zmq.socket('dealer')

sc.bindSync('tcp://*:' + '8888');
sw.connect('tcp://*:' + '8889');

sc.on('message',(w,sep,m)=> {
    console.log(m);
    if(m == 'inicializar') {
        work.push(w);
    }
    else if(m == '') {
        enviar();
    }    
})
sw.on('message',(w,sep,c,sep2,m)=> {
    console.log(m);
    sc.send(c,sep,m);
})

setInterval(enviar, 500);

function enviar() {
    if(work.length == 0) return;
    else {
        sw.send(work.shift(),'',req.shift());
    }
}