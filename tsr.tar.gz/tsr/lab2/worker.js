const zmq = require('zeromq')
let req = zmq.socket('req')

var port = process.argv[2];
var nick = process.argv[3];
var txt = process.argv[4];

req.identity = 'Worker1' + process.pid
req.connect(port)
req.on('message', (w, sep1, c, sep2, msg)=> {
    setTimeout(()=> {
        req.send([c,'',txt])
    },1000)
})
req.send(['','',''])