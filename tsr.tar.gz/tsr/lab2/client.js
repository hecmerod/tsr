const zmq = require('zeromq');
let req = zmq.socket('req');

var port = process.argv[2];
var nick = process.argv[3];

req.identity= nick
console.log("conectando a ",port)
req.connect(port,()=> console.log("conectado"));


req.on('message', (msg)=> {
    console.log('resp:'+msg)
    process.exit(0);
})

req.send('Hola');