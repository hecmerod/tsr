let pub = require('zeromq').socket('pub');

var port = process.argv.slice(2)[0];
var numMessages = process.argv.slice(2)[1];
var topics = process.argv.slice(4);

pub.bind('tcp://*:9999');



for(i = 1; i <= numMessages; i++) {
    setTimeout(sendTopic, i * 1000, i);
}

var x = 0; 
var y = 0;
function sendTopic(i) {
    var msg;
    topicsLength = topics.length;
    if(!topics[i-1]){ 
        if(x == 0) y++;
        msg = topics[x] + " " + y;
        x++;
        if(!topics[x]) { x = 0;}
    }
    else msg = topics[i - 1] + " " + y;
    console.log(msg);
    pub.send(msg)
}