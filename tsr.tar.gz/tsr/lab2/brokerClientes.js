const zmq = require('zeromq')
let cli=[], req=[]

let sc = zmq.socket('router')
let sw = zmq.socket('dealer')

sc.bindSync('tcp://*:' + '8888');
sw.bindSync('tcp://*:' + '8889');

sc.on('message',(c,sep,m)=> {
    console.log(m);
    cli.push(c); req.push(m); 
    enviar();
})

sw.on('message',(w,sep,m)=> {
    console.log(m);
    sc.send(c,sep,m);
})

setInterval(enviar, 500);

function enviar() {
    if(cli.length == 0) return;
    else {
        sw.send(cli.shift(),'',req.shift());
}